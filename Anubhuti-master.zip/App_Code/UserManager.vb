﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Web.Configuration
Imports System.Net.Mail
Imports System.Configuration
Imports System
Imports System.Web
Imports MySql.Data.MySqlClient


Public Class UserManager

    Private Shared db As New DBHelper


    Public Shared Function Validate2(ByVal userid As String, ByVal clientid As String) As DataSet

        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_userid", userid)
        parms(1) = New DBHelper.Parameters("i_clientid", clientid)
        'Return db.DataAdapter(CommandType.StoredProcedure, "SP_VALIDATEUSER", parms)
        Return db.DataAdapter(CommandType.StoredProcedure, "SP_VALIDATEUSER_ADVANCED", parms)

    End Function

    Public Shared Function Validate(ByVal userName As String, ByVal userPassword As String) As DataSet

        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_userName", userName)
        parms(1) = New DBHelper.Parameters("i_userPassword", userPassword)
        'Return db.DataAdapter(CommandType.StoredProcedure, "SP_VALIDATEUSER", parms)
        Return db.DataAdapter(CommandType.StoredProcedure, "SP_VALIDATEUSER_BASIC", parms)

    End Function

    Public Shared Function GetProduct(ByVal Client_ID As Integer) As String


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_Client_ID", Client_ID.ToString)
        Return db.ExecuteScalar(CommandType.StoredProcedure, "SP_GETPRODUCT", parms).ToString()

    End Function
    Public Shared Function GetProductFiles(ByVal Client_ID As Integer) As DataTable


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_Client_ID", Client_ID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GETPRODUCTFILES", parms)
        Return ds.Tables(0)

    End Function
    Public Shared Function GetResumeFiles(ByVal Client_ID As Integer) As DataTable


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_Client_ID", Client_ID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GETRESUMEFILES", parms)
        Return ds.Tables(0)

    End Function
    Public Shared Function GetProductTablesAndFields(ByVal Client_ID As String) As DataTable


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_Client_ID", Client_ID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GETPRODUCTTABLESANDFIELDS", parms)
        Return ds.Tables(0)

    End Function
    Public Shared Function CheckUploadStatus(ByVal iGUID As String, ByVal iclientid As Integer) As DataTable


        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("iclientid", iclientid)
        parms(1) = New DBHelper.Parameters("iGUID", iGUID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_CheckUploadStatus", parms)
        Return ds.Tables(0)

    End Function

    Public Shared Function CheckUploadStatusFinal(ByVal iGUID As String) As DataTable

        Dim dbc As New DBHelperClient
        Dim parms(0) As DBHelperClient.Parameters
        parms(0) = New DBHelperClient.Parameters("iGUID", iGUID)
        Dim ds As DataSet = dbc.DataAdapter(CommandType.StoredProcedure, "SP_CheckUploadStatusFinal", parms)
        Return ds.Tables(0)

    End Function

    Public Shared Sub UpdateStatusOnError(ByVal iGUID As String, ByVal iclientid As Integer, ByVal ifilename As String)

        Dim db1 As New DBHelper
        Dim parms(2) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("iclientid", iclientid)
        parms(1) = New DBHelper.Parameters("iGUID", iGUID)
        parms(2) = New DBHelper.Parameters("ifilename", ifilename.Trim)
        db1.ExecuteScalar(CommandType.StoredProcedure, "SP_UpdateStatusOnError", parms)

    End Sub

    Public Shared Sub ImportTextToDB1(ByVal ifilename As String, ByVal ifilepath As String, ByVal iGUID As String, ByVal iclientid As Integer, ByVal hasheader As Boolean)

        Dim db1 As New DBHelper
        Dim outstr As String = ""
        Dim filestr As String
        Dim parms() As DBHelper.Parameters
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            ReDim parms(4)
        Else
            ReDim parms(6)
            'Prepare File Path
            filestr = Format(iclientid, "0000")
            filestr = ConfigurationManager.AppSettings("linkedservername").ToString & "client_" & filestr
            Dim tempstr As String = "" '= Mid(ifilepath, 1, 2)
            'tempstr = tempstr & "\\data"
            If Right(ifilepath, 1) = "\" Then
                ifilepath = ifilepath.Substring(0, Len(ifilepath) - 1)
            End If
            tempstr = ifilepath
            'tempstr = tempstr & "\\" & filestr & "\\" & iGUID & "\\" & ifilename
            parms(5) = New DBHelper.Parameters("ifiletobeinserted", tempstr)
            parms(6) = New DBHelper.Parameters("hasheader", hasheader)

        End If
        parms(0) = New DBHelper.Parameters("ifilepath", ifilepath)
        parms(1) = New DBHelper.Parameters("ifilename", ifilename)
        parms(2) = New DBHelper.Parameters("iclientid", iclientid)
        parms(3) = New DBHelper.Parameters("iGUID", iGUID)
        parms(4) = New DBHelper.Parameters("outstr", outstr, ParameterDirection.Output)
        db1.ExecuteNonQuery(CommandType.StoredProcedure, "SP_CreateTable", parms)

        Dim count As Integer = 0
        Dim retVal As Integer = 0
        Dim ds As New DataSet()
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            outstr = db1.oCommand.Parameters("outstr").Value
            'Prepare File Path
            filestr = Format(iclientid, "0000")
            filestr = ConfigurationManager.AppSettings("linkedservername").ToString & "client_" & filestr
            Dim tempstr As String = Mid(ifilepath, 1, 2)
            tempstr = tempstr & "\\data"
            tempstr = tempstr & "\\" & filestr & "\\" & iGUID & "\\" & ifilename
            Dim cnt As Integer = InStr(ifilename, ".", CompareMethod.Text)
            Dim temptablestr As String = LCase(Mid(ifilename, 1, (cnt - 1)))
            'Dim sqlstr As String = "Load Data Infile '" & tempstr & "' "
            Dim sqlstr As String = "Load Data local Infile '" & ifilepath.Replace("\", "\\") & "' "
            'sqlstr = sqlstr + "  into Table " & filestr & ".temp" & temptablestr & " CHARACTER SET binary Fields Terminated by '\t' Lines Terminated by '\n'  " & " (" & outstr & ") "
            sqlstr = sqlstr + "  into Table " & filestr & ".temp" & temptablestr & " CHARACTER SET binary Fields Terminated by '\t' Lines Terminated by '\n'  "
            If hasheader Then
                sqlstr = sqlstr + " Ignore 1 lines "
            End If
            sqlstr = sqlstr & " (" & outstr & ") "
            If ifilename.Trim.ToLower.Equals("invoice_header.txt") Then
                sqlstr = sqlstr & " set projected_payment_date = nullif(@projected_payment_date,'NULL')"
                sqlstr = sqlstr & ",approved_on = if(trim(approved_on) = '',NULL,approved_on)"
                sqlstr = sqlstr & ",received_on = if(trim(received_on) = '',NULL,received_on)"
                'ElseIf ifilename.Trim.ToLower.Equals("vendor_master.txt") Then
                '    sqlstr = sqlstr & " set created_on = if(trim(created_on) = '',NULL,created_on)"
                'ElseIf ifilename.Trim.ToLower.Equals("vendor_address.txt") Then
                '    sqlstr = sqlstr & " set entered_on = if(trim(entered_on) = '',NULL,entered_on)"
            End If
            If sqlstr.Contains("created_on") Then
                sqlstr = sqlstr & " set created_on = if(trim(created_on) = '',NULL,created_on)"
            End If
            If sqlstr.Contains("entered_on") Then
                sqlstr = sqlstr & " set entered_on = if(trim(entered_on) = '',NULL,entered_on)"
            End If
            db1.ExecuteNonQuery(CommandType.Text, sqlstr)
            'sqlstr = sqlstr.Replace("'", "''")
            'db1.ExecuteNonQuery(CommandType.Text, "insert into tblfileloader (GUID,CLIENTDB,LOADSQL,STARTED,COMPLETED) values('" + iGUID + "','" + "client_" + Format(iclientid, "0000") + "','" + sqlstr + "',0,0)")
            'System.Threading.Thread.Sleep(60000)
            'Else
            '    outstr = db1.oCommand.Parameters("outstr").Value
            '    'Prepare File Path
            '    filestr = Format(iclientid, "0000")
            '    filestr = ConfigurationManager.AppSettings("linkedservername").ToString & "client_" & filestr
            '    Dim tempstr As String = Mid(ifilepath, 1, 2)
            '    tempstr = tempstr & "\\data"
            '    tempstr = tempstr & "\\" & filestr & "\\" & iGUID & "\\" & ifilename
            '    Dim cnt As Integer = InStr(ifilename, ".", CompareMethod.Text)
            '    Dim temptablestr As String = LCase(Mid(ifilename, 1, (cnt - 1)))
            '    Dim sqlstr As String = "BULK INSERT " & filestr & ".dbo.temp" & temptablestr & " from '" & tempstr & "'"
            '    sqlstr = sqlstr + "  WITH (DATAFILETYPE = 'native', FIELDTERMINATOR = '\t', ROWTERMINATOR = '\n'"
            '    If hasheader Then
            '        sqlstr = sqlstr + " ,FIRSTROW=2,KEEPIDENTITY) "
            '    Else
            '        sqlstr = sqlstr + ",KEEPIDENTITY)"
            '    End If
            '    db1.ExecuteNonQuery(CommandType.Text, sqlstr)
        End If

        ' old commneted code
        'Dim sqlstr As String = "Load Data Infile 'e:data\\client_0022\\5e77cd27-9f54-4cbb-83c6-380a7cb37d83\\Invoice_Header.txt'  "
        'sqlstr = sqlstr + "  into Table client_0022.tempinvoice_header Fields Terminated by '\t' Lines Terminated by '\n' "

        'Load Data Infile 'e:\\data\\client_0022\\dff7d48b-a0a6-44e0-a18f-a5733fc4e61a\\Invoice_Header.txt' 
        'into Table client_0022.tempinvoice_header Fields Terminated by '"\t"' Lines Terminated by '\n'  Ignore 1 lines

        'sqlstr = sqlstr + "  into Table " & filestr & ".temp" & temptablestr & " CHARACTER SET binary Fields Terminated by '\t'  Lines Terminated by '\n'  " & " (" & outstr & ") "
        'If strWithQuotes = "Y" Then
        '    sqlstr = sqlstr + "  into Table " & filestr & ".temp" & temptablestr & " Fields Terminated by '\t'  ESCAPED BY '' Lines Terminated by '\n'"
        '    If hasheader Then
        '        sqlstr = sqlstr + " Ignore 1 lines "
        '    End If
        'Else

        '    sqlstr = sqlstr + "  into Table " & filestr & ".temp" & temptablestr & " Fields Terminated by '\t' ESCAPED BY '' Lines Terminated by '\n' "
        '    If hasheader Then
        '        sqlstr = sqlstr + " Ignore 1 lines "
        '    End If
        'End If

    End Sub

    Public Shared Function ImportTextToDB2(ByVal ifilename As String, ByVal ifilepath As String, ByVal iGUID As String, ByVal iclientid As Integer) As String

        Dim db1 As New DBHelper
        Dim outstr As String = "Complete"
        Dim parms() As DBHelper.Parameters
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            ReDim parms(3)
        Else
            ReDim parms(2)
        End If
        parms(0) = New DBHelper.Parameters("ifilename", ifilename)
        parms(1) = New DBHelper.Parameters("iclientid", iclientid)
        parms(2) = New DBHelper.Parameters("iGUID", iGUID)
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            parms(3) = New DBHelper.Parameters("outstr", outstr, ParameterDirection.Output)
            db1.ExecuteScalar(CommandType.StoredProcedure, "SP_ImportTextFile", parms)
        Else
            outstr = db1.ExecuteScalar(CommandType.StoredProcedure, "SP_ImportTextFile", parms)
        End If
        'Dim count As Integer = 0
        'Dim retVal As Integer = 0
        'Dim ds As New DataSet()
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            outstr = db1.oCommand.Parameters("outstr").Value
        End If

        Return outstr

    End Function

    Public Shared Function GetErrDetails(ByVal strFileName As String, ByVal strGUID As String) As DataSet


        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_strFileName", strFileName)
        parms(1) = New DBHelper.Parameters("i_strGUID", strGUID)
        Return db.DataAdapter(CommandType.StoredProcedure, "SP_GetErrDetails", parms)

    End Function

    Public Shared Function GetValidationErrDetails(ByVal clientId As String, ByVal strGUID As String, ByVal internaltable As String) As DataSet


        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_clientid", clientId)
        parms(1) = New DBHelper.Parameters("i_strGUID", strGUID)
        Return db.DataAdapter(CommandType.StoredProcedure, "SP_GetValidationErrDetails", parms)

    End Function


    Public Shared Sub InsertStatus(ByVal Client_ID As Integer, ByVal GUID As String, ByVal stepno As Integer, ByVal strFiles As String, ByVal strFileHasHeader As String, ByVal strStatus As String, ByVal nextenabled As Integer)


        Dim parms(7) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("ClientID", Client_ID)
        parms(1) = New DBHelper.Parameters("i_GUID", GUID)
        parms(2) = New DBHelper.Parameters("StepNo", stepno)
        parms(3) = New DBHelper.Parameters("QueryType", "Insert")
        parms(4) = New DBHelper.Parameters("strFiles", strFiles)
        parms(5) = New DBHelper.Parameters("strFileHasHeader", strFileHasHeader)
        parms(6) = New DBHelper.Parameters("strStatus", strStatus)
        parms(7) = New DBHelper.Parameters("nextenabled", nextenabled)
        db.ExecuteNonQuery(CommandType.StoredProcedure, "SP_InsertUpdateStatus", parms)

    End Sub

    Public Shared Function GetReviewData(ByVal ClientID As Integer, ByVal GUID As String, ByVal files As String) As DataSet


        Dim strFiles() As String
        Dim filesIN As String = ""
        strFiles = files.ToString().Trim().Split(vbCrLf)

        For index As Integer = 0 To strFiles.Length - 1
            filesIN = filesIN & strFiles(index) & ","
        Next
        filesIN = filesIN.Substring(0, filesIN.Length - 1)


        Dim parms(2) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("iclientid", ClientID)
        parms(1) = New DBHelper.Parameters("iGUID", GUID)
        parms(2) = New DBHelper.Parameters("files", filesIN)
        Return db.DataAdapter(CommandType.StoredProcedure, "SP_ReviewData", parms)

    End Function

    Public Shared Function GetTablesAndFields(ByVal FileName As String) As DataTable


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_filename", FileName)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GetTablesAndFieldsByFile", parms)
        Return ds.Tables(0)

    End Function

    Public Shared Function StatusRecordExists(ByVal client_id As Integer) As Boolean


        Dim count As Integer = CType(db.ExecuteScalar(CommandType.Text, "SELECT COUNT(*) FROM UploadFileStatus WHERE Client_ID=" + client_id.ToString + " and  coalesce(status,'Fail') <> 'Complete'"), Integer)
        Dim result As Boolean = False
        If count > 0 Then
            result = True
        End If
        Return result
    End Function

    Public Shared Function GetStepNo(ByVal Client_ID As Integer) As DataTable
        Dim ds As DataSet
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            ds = db.DataAdapter(CommandType.Text, "Select StepNo from UploadFileStatus where Client_ID=" + Client_ID.ToString + " order by modifieddate desc limit 1")
        Else
            ds = db.DataAdapter(CommandType.Text, "Select top 1 StepNo from UploadFileStatus where Client_ID=" + Client_ID.ToString + " order by modifieddate desc")
        End If
        Return ds.Tables(0)

    End Function

    Public Shared Function DeleteStatusRecord(ByVal Client_ID As Integer) As Boolean


        Dim result As Boolean = False
        result = Convert.ToBoolean(db.ExecuteNonQuery(CommandType.Text, "Delete from UploadFileStatus where Client_ID= " + Client_ID.ToString))
        Return result

    End Function
    Public Shared Sub LoadSource(ByVal strClientID As String)



        Dim tablename As String = ""
        Dim strFiles() As String = HttpContext.Current.Session("files").ToString.Trim.Split(vbCrLf)
        'Dim params(3, 2) As Object
        Dim parms(2) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("strClientID", strClientID)
        parms(1) = New DBHelper.Parameters("userid", HttpContext.Current.Session("user_id"))
        'Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_LoadSource2", parms)

        Dim res As Integer = 0
        For i As Integer = 0 To strFiles.Length - 1
            If i <> 0 Then
                db.oCommand.Parameters.RemoveAt("vtable_name")
            End If
            tablename = strFiles(i).Substring(0, strFiles(i).Length - 4)
            parms(2) = New DBHelper.Parameters("vtable_name", tablename.Trim)
            db.DataAdapter(CommandType.StoredProcedure, "SP_LoadSource2", parms)
        Next

    End Sub

    Public Shared Function GetGUID(ByVal Client_ID As Integer) As String

        Dim result As String = ""
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            result = db.ExecuteScalar(CommandType.Text, "Select GUID from UploadFileStatus where Client_ID=" + Client_ID.ToString + " LIMIT 1").ToString()
        Else
            result = db.ExecuteScalar(CommandType.Text, "Select top 1 GUID from UploadFileStatus where Client_ID=" + Client_ID.ToString).ToString()
        End If
        Return result
    End Function

    Public Shared Function GetValidationResults(ByVal Client_ID As Integer, ByVal GUID As String) As DataTable


        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("iclientid", Client_ID)
        parms(1) = New DBHelper.Parameters("iGUID", GUID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_RunValidationScript", parms)
        Return ds.Tables(0)
    End Function

    Public Shared Function GetErrorSummary(ByVal Client_ID As Integer, ByVal GUID As String) As DataTable


        Dim parms(1) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_clientid", Client_ID)
        parms(1) = New DBHelper.Parameters("i_strGUID", GUID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GetErrorSummary", parms)
        Return ds.Tables(0)

    End Function

    Public Shared Function GetMaxCols(ByVal Client_ID As Integer) As DataTable


        Dim parms(0) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("i_clientid", Client_ID)
        Dim ds As DataSet = db.DataAdapter(CommandType.StoredProcedure, "SP_GetMaxCols", parms)
        Return ds.Tables(0)

    End Function
    Public Shared Sub Run_Group(ByVal groupid As Integer, ByVal iclientid As Integer, ByVal iGUID As String)

        'Dim userid As String = HttpContext.Current.Session("UserID")
        'db.ExecuteNonQuery(CommandType.Text, "delete from RunGroupStatus where client_ID = " & iclientid & " and GUID = '" & iGUID & "'")

        Dim outstr As String = ""


        'Dim parms(2) As DBHelper.Parameters
        'parms(0) = New DBHelper.Parameters("i_groupid", groupid)
        'parms(1) = New DBHelper.Parameters("i_client_ID", iclientid)
        'parms(2) = New DBHelper.Parameters("i_GUID", iGUID)
        'db.ExecuteNonQuery(CommandType.StoredProcedure, "SP_GenerateTaskList", parms)


        Dim parms2() As DBHelper.Parameters
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            ReDim parms2(2)
        Else
            ReDim parms2(1)
        End If
        parms2(0) = New DBHelper.Parameters("iclientid", iclientid)
        parms2(1) = New DBHelper.Parameters("iGUID", iGUID)
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            parms2(2) = New DBHelper.Parameters("outstr", outstr, ParameterDirection.Output)
        End If
        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            'db.ExecuteNonQuery(CommandType.StoredProcedure, "SP_RunGroup", parms2)
            'outstr = db.oCommand.Parameters("outstr").Value
            'outstr = outstr.Replace("?", "\?")
            'Dim dbc As New DBHelperClient
            'dbc.ExecuteNonQuery(CommandType.Text, outstr)

            Dim dbc As New DBHelperClient

            'update the guid in source tables!
            Dim tablename As String = ""
            Dim strFiles() As String = HttpContext.Current.Session("files").ToString.Trim.Split(vbCrLf)
            'Dim params(3, 2) As Object
            Dim parms(1) As DBHelperClient.Parameters
            Dim res As Integer = 0
            For i As Integer = 0 To strFiles.Length - 1
                If i <> 0 Then
                    db.oCommand.Parameters.RemoveAt("vtable_name")
                End If
                tablename = strFiles(i).Substring(0, strFiles(i).Length - 4)
                parms(0) = New DBHelperClient.Parameters("vtable_name", tablename.Trim)
                parms(1) = New DBHelperClient.Parameters("strGUID", iGUID)
                dbc.DataAdapter(CommandType.StoredProcedure, "SP_UpdateGuid", parms)
                dbc.ExecuteNonQuery(CommandType.StoredProcedure, "SP_QueueVendor", parms)
            Next



            'dbc.ExecuteNonQuery(CommandType.Text, String.Format(" if not exists(select * from vendor_queue where session_id = '{0}') then INSERT INTO `vendor_queue`(session_id, state, source) VALUES ('{0}','PENDING','vendor_file'); end if;", iGUID))

            '' now need to check on the event scheduler!
            'Dim parms3(0) As DBHelperClient.Parameters
            'parms3(0) = New DBHelperClient.Parameters("iGUID", iGUID)
            'dbc.ExecuteNonQuery(CommandType.StoredProcedure, "SP_CheckRunGroupCompletion", parms3)




            'Dim parms3(1) As DBHelper.Parameters
            'parms3(0) = New DBHelper.Parameters("iclientid", iclientid)
            'parms3(1) = New DBHelper.Parameters("iGUID", iGUID)
            'db.ExecuteNonQuery(CommandType.StoredProcedure, "SP_CheckRunGroupCompletion", parms3)

            'Dim dbc_clean As New DBHelperClient
            'dbc_clean.ExecuteNonQuery(CommandType.Text, "Drop procedure `" & iGUID & "`")

        Else
            outstr = db.ExecuteScalar(CommandType.StoredProcedure, "SP_RunGroup", parms2)
        End If

        'Dim cmd As New MySql.Data.MySqlClient.MySqlCommand
        'Dim con As New MySql.Data.MySqlClient.MySqlConnection
        'con.ConnectionString = ConfigurationManager.ConnectionStrings("mysqlconn").ConnectionString
        'con.Open()
        'cmd.Connection = con
        'cmd.CommandText = "CALL udp_relate_the_vendors();"
        'cmd.CommandType = CommandType.Text
        'cmd.ExecuteNonQuery()

        If ConfigurationManager.AppSettings("DATA.PROVIDER").ToString.Contains("MySql") Then
            ' instead of running all the group tasks here...just create a proc with the GUID's name and insert into QUEUE table! -- THIS IS ALL DINE IN SP_RUNGROUP!!!
            ' SO now...here just check the event scheduler status and display to user!

            'Dim cmd As New Devart.Data.MySql.MySqlCommand
            ''Dim con As New Devart.Data.MySql.MySqlConnection(ConfigurationManager.ConnectionStrings("mysqlconnstring").ConnectionString)
            'Dim con As New Devart.Data.MySql.MySqlConnection(HttpContext.Current.Session("clientconnstringdevart"))
            'con.Open()
            'cmd.Connection = con
            'cmd.CommandText = outstr
            'cmd.CommandTimeout = 0
            ''cmd.CommandText = "CALL udp_relate_the_vendors(TRUE,TRUE);"
            'cmd.CommandType = CommandType.Text
            'cmd.ExecuteNonQuery()
        Else
            Dim dbc As New DBHelperClient
            'outstr = outstr.Replace("?", "\?")
            dbc.ExecuteNonQuery(CommandType.Text, outstr)
        End If


        ''Dim dbc As New DBHelperClient
        ' ''outstr = outstr.Replace("?", "\?")
        ''dbc.ExecuteNonQuery(CommandType.Text, outstr)

        'Dim dbc2 As New DBHelperClient
        'Dim parms3(1) As DBHelperClient.Parameters
        'parms3(0) = New DBHelperClient.Parameters("include_match_key", True)
        'parms3(1) = New DBHelperClient.Parameters("include_singles", True)
        'dbc2.ExecuteNonQuery(CommandType.StoredProcedure, "udp_relate_the_vendors", parms3)

        'dbc2.ExecuteNonQuery(CommandType.Text, outstr)
        'dbc2.ExecuteNonQuery(CommandType.Text, "CALL udp_relate_the_vendors(TRUE,TRUE);")

        '' ''Dim i As Integer = dbc.ExecuteNonQuery(CommandType.Text, outstr)

        '' ''Dim i As Integer = dbc.ExecuteNonQuery(CommandType.Text, "Call udp_import_wrapper('VENDOR_FILE');")
        ' ''Dim parms3(0) As DBHelperClient.Parameters
        ' ''parms3(0) = New DBHelperClient.Parameters("i_text", outstr)
        ' ''dbc.ExecuteNonQuery(CommandType.Text, "CREATE DEFINER=`root`@`localhost` PROCEDURE `test2`() BEGIN " & "Call udp_import_wrapper('VENDOR_FILE');" & " END")
        '' ''HttpContext.Current.Response.Write(i)
        ' ''dbc.ExecuteNonQuery(CommandType.StoredProcedure, "test2")

    End Sub

    Public Shared Sub UpdateClientContactOnError(ByVal Client_ID As Integer, ByVal GUID As String, ByVal EmailID As String, ByVal ContactPhone As String, ByVal ErrorMessage As String)


        Dim parms(4) As DBHelper.Parameters
        parms(0) = New DBHelper.Parameters("ClientID", Client_ID)
        parms(1) = New DBHelper.Parameters("i_GUID", GUID)
        parms(2) = New DBHelper.Parameters("i_EmailID", EmailID)
        parms(3) = New DBHelper.Parameters("i_ContactPhone", ContactPhone)
        parms(4) = New DBHelper.Parameters("i_ErrorMessage", ErrorMessage)
        db.ExecuteNonQuery(CommandType.StoredProcedure, "SP_UpdateClientContactOnError", parms)

    End Sub
    Public Shared Function ValidateUserNameForForgotPassword(ByVal email As String) As Boolean


        Dim bIsValid As Boolean = False
        Dim ds As DataSet = db.DataAdapter(CommandType.Text, "Select * from Users where email='" + email + "'")
        If ds.Tables(0).Rows.Count > 0 Then
            bIsValid = True
            Return bIsValid
        End If
        Return bIsValid
    End Function
    Public Shared Sub ChangePassword(ByVal strPass As String, ByVal strUserID As String)


        db.ExecuteNonQuery(CommandType.Text, "Update Users set userPassword = '" & strPass & "' where userID=" & strUserID).ToString()
    End Sub

    Public Shared Function GetPasswordFromEmail(ByVal Email As String) As String


        Dim strPass As String = db.ExecuteScalar(CommandType.Text, "Select userPassword from Users where email='" + Email + "'").ToString
        Return strPass
    End Function

    Public Shared Sub SendForgotPasswordMail(ByVal userEmail As String, ByVal userPwd As String)
        '!!! UPDATE THIS VALUE TO USER's EMAIL ADDRESS
        Dim FromAddress As String = WebConfigurationManager.AppSettings("TICSupportEmail")
        '(1) Create the MailMessage instance
        Dim mailMsg As New MailMessage(FromAddress, userEmail)
        '(2) Assign the MailMessage's properties
        mailMsg.Subject = WebConfigurationManager.AppSettings("TICEmailSubjectForgot").ToString()
        mailMsg.Body = WebConfigurationManager.AppSettings("TICEmailBodyForgot").ToString() & " : " & userPwd
        'mailMsg.Body = mailMsg.Body & vbCrLf & WebConfigurationManager.AppSettings("TICEmailBodyLineURL").ToString()
        'mailMsg.Body = mailMsg.Body & vbCrLf & "Enter " & userEmail & " as Username and " & userPwd & " as password."
        mailMsg.Body = mailMsg.Body & vbCrLf & "Thank you."
        mailMsg.IsBodyHtml = False
        '(3) Create the SmtpClient object
        Dim smtp As New SmtpClient
        '(4) Send the MailMessage (will use the Web.config settings)
        Dim obj As Object = New Object()
        smtp.SendAsync(mailMsg, obj)
    End Sub

End Class