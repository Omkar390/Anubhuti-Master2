// general functionality

jQuery(function($) {


    $(".star_rating").on("click", ".star", function() {

        var $this = $(this), classes = $this.attr("class").split(/\s/);

        $this.parent().removeClass().addClass("star_rating active_" + classes[1]);

        $("#hdnStarValue").val(classes[1]);

    });

    if ($(".datepicker").length > 0) {

        $(".datepicker").datepicker({
            showOtherMonths: true,
            selectOtherMonths: true,
            changeYear: true,
            changeMonth: true
        });

    }

    if ($(".step_slider").length > 0) {
        $(".step_slider").slider({
            range: "min",
            min: 1,
            max: 100,
            slide: function(event, ui) {
                $(this).next(".slider_step").text(ui.value);
            }
        });

    }


    $(".popup").each(function() {

        var $this = $(this), h = $this.outerHeight();
        $this.css("margin-top", -h / 2);

    });


});    //end jQuery

